import React from "react";

function About(){
    
    return(
        <>
            <div className="about-section">
            <h1>About Section</h1>
            <p>This is my about section!</p>
            </div>
        </>
    )
    
}

export default About;